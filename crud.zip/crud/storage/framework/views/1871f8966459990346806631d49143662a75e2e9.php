  <?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <h1>Edit Data</h1>
    </div>
  </div>
  <div class="row">
    <form class="" action="<?php echo e(route('blog.update',$blog->id)); ?>" method="post">
      <input name="_method" type="hidden" value="PATCH">
      <?php echo e(csrf_field()); ?>

      <div class="form-group<?php echo e(($errors->has('title')) ? $errors->first('title') : ''); ?>">
        <input type="text" name="title" class="form-control" placeholder="Enter Title Here" value="<?php echo e($blog->title); ?>">
        <?php echo $errors->first('title','<p class="help-block">:message</p>'); ?>

      </div>
      <div class="form-group<?php echo e(($errors->has('description')) ? $errors->first('title') : ''); ?>">
        <input type="text" name="description" class="form-control" placeholder="Enter Description Here" value="<?php echo e($blog->description); ?>">
        <?php echo $errors->first('description','<p class="help-block">:message</p>'); ?>

      </div>
      <div class="form-group">
        <input type="submit" class="btn btn-primary" value="save">
      </div>
    </form>
  </div>


  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>