  <?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <h1>Create Blog</h1>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <form class="" action="<?php echo e(route('blog.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group<?php echo e(($errors->has('title')) ? $errors->first('title') : ''); ?>">
          <input type="text" name="title" class="form-control" placeholder="Enter Title Here">
          <?php echo $errors->first('title','<p class="help-block">:message</p>'); ?>

        </div>
        <div class="form-group<?php echo e(($errors->has('description')) ? $errors->first('title') : ''); ?>">
           <textarea class="form-control" name="description" rows="5" id="description" placeholder="Enter description Here"></textarea>
          <!-- <input type="text" name="description" class="form-control" placeholder="Enter Description Here"> -->
          <?php echo $errors->first('description','<p class="help-block">:message</p>'); ?>

        </div>
        <div class="form-group">
          <input type="submit" class="btn btn-primary" value="save">
        </div>
      </form>
    </div>
  </div>














  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>