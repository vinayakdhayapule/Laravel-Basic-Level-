<p>create root level category</p>
<form class="mt-10" action="{{rout('sub')}}" method="post">
{{csrf_field()}}
<select>
	@foreach($sub as $value)
	<option value="name">
{{ $value }}
	</option>
</select>

<input type="text" name="name" value="">
<input type="submit" name="" value="submit">
</form>