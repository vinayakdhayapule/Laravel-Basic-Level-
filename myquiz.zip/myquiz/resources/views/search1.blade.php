<!DOCTYPE html>
<html>
<head>
<style>
table, th, td { border: 3px solid black; border-collapse: collapse;}
th, td { padding: 5px;}
input[type="text"] { width: 172px;height: 21px;border-radius: 2px;}
input[type="number"] {width: 172px;height: 21px;border-radius:}
input[type="submit"] {font-size: 15px;font-family: monospace;background-color: #51A3E0;color: #fff;border-radius: 5px;width: 79px;height: 33px;}
</style>
</head>
<body>
<form method="post" action="{{route('post-search')}}">
  <input type="text" name="name" placeholder="Search.."></br></br>
  <input type="hidden" name="_token" value="{{ csrf_token() }}">
  <input type="number" name="min"></br></br>
  <input type="number" name="max"></br></br>
<input type="submit" name="" value="submit">
</form>
</br>

@if(!empty($article))
<table>
 <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Price</th>
    <th>Stock</th>
  </tr>
  @foreach($article as $article)
  <tr>
    <td>{{$article->id}}</td>
    <td>{{$article->product_name}}</td>
    <td>{{$article->price}}</td>
    <td>{{$article->stock}}</td>
  </tr>
  @endforeach

</table>
@endif

</body>
</html>