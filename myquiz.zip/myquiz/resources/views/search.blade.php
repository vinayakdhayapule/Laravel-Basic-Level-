@extends('layouts.app')

@section('content')
{{ $success = Session::get('success') }}
@if($success)
    <div class="alert-box success">
        <h2>{{ $success }}</h2>
    </div>
@endif
    <div class="container">
        <div class="col-sm-6 col-sm-6">
            @include('flash::message')
                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!-- New Task Form -->
                    <form action="{{route('post-search')}}" method="POST" class="form-horizontal">
                        {{ csrf_field() }}
                        <!-- Task Name -->
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Product Search</label>
                            <div class="col-sm-6">
                            <input type="text" name="name" placeholder="Search.." id="task-name" class="form-control" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">From</label>
                            <div class="col-sm-6">
                            <input type="number" name="min" id="task-name" class="form-control" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">To</label>
                            <div class="col-sm-6">
                            <input type="number" name="max" id="task-name" class="form-control" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" class="form-control">
                            </div>
                        </div>
                        <!-- Add Task Button -->
                        <!-- <div class="form-group"> -->
                            <div class="col-sm-offset-3 col-sm-3">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>submit
                                </button>
                            </div>
                        <!-- </div> -->
                    </form>
                    </div>
                             @if(!empty($article))
                                 <div class="table-responsive">
                                 <table class="table">
                                 <tr>
                                    <th>Product ID</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                  </tr>
                                  @foreach($article as $article)
                                  <tr>
                                    <td>{{$article->id}}</td>
                                    <td>{{$article->product_name}}</td>
                                    <td>{{$article->price}}</td>
                                    <td>{{$article->stock}}</td>
                                  </tr>
                                  @endforeach

                                </table>
                                </div>
                                @endif
                </div>
                </div>
        </div>
    </div>
@endsection
