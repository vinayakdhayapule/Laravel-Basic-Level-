<!DOCTYPE html>
<html lang="en" ng-app='itdukanapp'>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title></title>
    <link rel="icon" href="{{url('/')}}/public/images/IT_fav.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="{{url('/')}}/public/images/IT_fav.ico" type="image/x-icon" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('public/awesome/css/font-awesome-latest.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/alert/alert.css') }}">
    <link rel="stylesheet" href="{{ asset('public/js/rating/rating.css') }}">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script>
</head>
<body class="cms-index-index">
<div class="progress-modal"></div>
<img class='body-waiting' style="display:none;" src="{{asset('public/images/loading.gif')}}">
<div class="page">
    <div style="position: fixed;top:350px;right:0;z-index:999;"><a data-toggle="modal" href="#modal-feedback">
            <img src="{{url('/')}}/public/feedback.png"></a>
    </div>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Tell us what your mind thinks.</h4>
                </div>
                <form id="feedback-form">
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="inputEmail3" class="control-label">Your Name</label>
                            <input type="text" name="name" id="feedback_name" class="form-control tooltips"
                                   id="inputEmail3" placeholder="Enter Your Name">
                        </div>
                        <!-- /.form-group -->


                        <div class="form-group">
                            <label for="inputEmail3" class="control-label">Email</label>
                            <input type="email" name="email" id="feedback_email" class="form-control tooltips"
                                   id="inputEmail3" placeholder="Enter Your Email">
                        </div>
                        <!-- /.form-group -->


                        <div class="form-group">
                            <label for="inputEmail3" class="control-label">Message</label>
                            <textarea name="feedback_message" id="feedback_message" class="form-control"
                                      placeholder="Enter Message"></textarea>
                        </div>
                        <!-- /.form-group -->
                    </div>

                    <div class="clearfix"></div>
                    <div class="modal-footer">

                        <input type="reset" value="Clear" class="btn btn-danger" name="reset">
                        <button type="submit" id="feedback" class="btn btn-primary">Submit</button>
                    </div>
            </form>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
</div>
<!-- JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="{{asset('public/js/rating/rating.js')}}"></script>
<script type="text/javascript">
    $(function () {
        $('.rating-block').rating();
    });
</script>
<script>
    $(document).ready(function() {
        $("#cart-sidebar").mCustomScrollbar({
            setHeight: 150,
            theme: "dark-3"
        });
        $('.header-top-hidden').slideUp(2000);
        $('.market-link').click(function () {
            $('.header-top-hidden').slideToggle(500);
            $('.market-link a i').toggleClass('glyphicon-triangle-bottom, glyphicon-triangle-top');
            // return false;
        });
        $('.search-block img').click(function () {
            $('.search-block input').fadeToggle(500);
            //$(this).attr('src', 'images/search-close.png');
            // return false;
        });
        $('.top-menu-icon').click(function () {
            $('.nihar-market-nav').slideToggle(500);
            // return false;
        });

        $('#feedback').on("click", function (e) {
            e.preventDefault();
            var data = $('#feedback-form').serialize();
            $.ajax({
                method: 'POST',
                url: '/feedback',
                data: data,
                success: function (data) {
                    switch (data) {
                        case '1':
                            swal("Good job!", "Thanks for your feedback", "success");
                            $('#modal-feedback').modal('hide');
                            $('#feedback-form input[name="reset"]').trigger('click');
                            break;
                        case '2':
                            swal("Oh! No", "Problem while submitting", "error");
                            $('#modal-feedback').modal('hide');

                            break;
                    }
                }
            });
            return false;
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {

$body = $("body");

$('.items-page').on({
    ajaxStart: function() { $("body").addClass("loading");    },
     ajaxStop: function() { $body.removeClass("loading"); }
});
        $('#subscribe').on("click", function () {
            var email = $('#email').val();
            if (email !== '') {
                $.ajax({
                    method: 'POST',
                    url:  '/subscribe',
                    // data: { email:email,_token:_token},
                    data: {email: email},
                    success: function (data) {
                        switch (data) {
                            case '1':
                                swal("Good job!", "Newsletter Subscribed Successfully!!", "success");
                                break;
                            case '2':
                                swal("Information", "Email Already Subscribed!!", "warning");
                                break;
                            case '3':
                                swal("Oh! No", "Invalid Email", "error");
                                break;
                            default:
                                swal("Information", "Please Enter Valid Email", "warning");
                        }
                        // $('#alert-email').html(data);
//                        $('#alert-email').slideDown().html(data).delay(1500).slideUp("slow");
                    }
                });
            }
            else {
                swal("Information", "Please Enter Valid Email", "warning");
            }
            return false;
        });
    });
</script>
<script>
        var baseURL = '{{ url('/') }}/';
    </script>
</body>
</html>