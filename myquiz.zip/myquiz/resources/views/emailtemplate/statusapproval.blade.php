<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Itdukaan.com</title>
</head>

<body>
<p>hi all</p>
<p><a  href="http://localhost/myquiz/verify/{{$user->code}}/{{$user->user_id}}">click here</a></p>
</body>
</html>