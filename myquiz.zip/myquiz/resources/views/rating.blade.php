@extends('layouts.app')

@section('content')
{{ $success = Session::get('success') }}
@if($success)
    <div class="alert-box success">
        <h2>{{ $success }}</h2>
    </div>
@endif
    <div class="container">
        <div class="col-sm-6 col-sm-6">
            @include('flash::message')
                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!-- New Task Form -->
                    <form action="{{route('postRating')}}" method="POST" class="form-horizontal">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Rating</label>
                            <div class="col-sm-6">
                            <section class="rating-block col-xs-12 row">
                                    <input type="radio" name="rating" class="rating" value="1"/>
                                    <input type="radio" name="rating" class="rating" value="2"/>
                                    <input type="radio" name="rating" class="rating" value="3"/>
                                    <input type="radio" name="rating" class="rating" value="4"/>
                                    <input type="radio" name="rating" class="rating" value="5"/>
                            </section>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" class="form-control">
                            </div>
                        </div>
                        <!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                </div>
        </div>
    </div>
@endsection
