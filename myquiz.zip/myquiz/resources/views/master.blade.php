<!DOCTYPE html>
<html>
<head>
	<title></title>
  <script type="text/javascript">
        $current_url = {{\Request::url()}}

        </script> 
</head>
<style type="text/css">
.alert.alert-success {
    color: #731313;
    font-size: 25px;
    font-family: open sans-serif;
    font-weight: 600;
    background-color: white;
    text-transform: capitalize;
}

</style>
<body>
@include('flash::message')

@yield('content')

</body>
</html>