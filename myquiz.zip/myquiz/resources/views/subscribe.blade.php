@extends('layouts.app')

@section('content')
{{ $success = Session::get('success') }}
@if($success)
    <div class="alert-box success">
        <h2>{{ $success }}</h2>
    </div>
@endif
    <div class="container">
        <div class="col-sm-6 col-sm-6">
            @include('flash::message')
                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!-- New Task Form -->
        <form action="{{route('postnewsletter')}}" method="POST" class="form-horizontal">
                        <!-- Task Name -->
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Name</label>
                            <div class="col-sm-6">
                            <input type="text" name="name" id="task-name"  class="form-control tooltips" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Email</label>
                            <div class="col-sm-6">
                        <input name="email" class="form-control tooltips" id="task-name" value="">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-6">
                                <input type="hidden" name="_token" value="{{csrf_token()}}" class="form-control">
                            </div>
                        </div>
                        <!-- Add Task Button -->
                        <!-- <div class="form-group"> -->
                            <div class="col-sm-offset-3 col-sm-3">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>submit
                                </button>
                            </div>
                        <!-- </div> -->
                    </form>
                </div>
                </div>
        </div>
    </div>
@endsection
