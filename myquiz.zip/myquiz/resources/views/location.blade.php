<!DOCTYPE html>
<html>
<body>
  <select name="location">
 @foreach($local as $lo)
    <option value="{{$lo->id}}">{{$lo->name}}</option>
 @endforeach
 </select></br><br/>
  <select name="state">
    <option value="state">india</option>
    <option value="state">india</option>
    <option value="state">india</option>
    <option value="state">india</option>
  </select></br><br/>
   <select name="city">
    <option value="city">india</option>
    <option value="city">india</option>
    <option value="city">india</option>
    <option value="city">india</option>
  </select></br><br/>



</body>
</html>
