<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="{{ asset('public/js/rating.css') }}">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script>
</head>
<body>
@include('flash::message')
<form method="post" action="{{route('postRating')}}">
<input type="hidden" name="_token" value="{{csrf_token()}}">
    <section class="rating-block col-xs-12 row">
        <input type="radio" name="rating" class="rating" value="1"/>
        <input type="radio" name="rating" class="rating" value="2"/>
        <input type="radio" name="rating" class="rating" value="3"/>
        <input type="radio" name="rating" class="rating" value="4"/>
        <input type="radio" name="rating" class="rating" value="5"/>
    </section>
<button type="submit" id="feedback" class="btn btn-primary">Submit</button>
</form>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="{{asset('public/js/rating.js')}}"></script>
<script type="text/javascript">
    $(function () {
        $('.rating-block').rating();
    });
</script>

</body>
</html>