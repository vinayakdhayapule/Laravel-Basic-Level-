<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="">
{{csrf_field()}}
<div class="row">

<div class="col-lg-4 col-md-4 col-sm-4">
<p>Country</p>
</div>
<div class="col-lg-8 col-md-8 col-sm-8">
<select name="country" id="select-country" onchange="getCountryStateCity({location_id:this.value,location_type:1}, 'state')" required>
<option value="">Select Your Country</option>
@foreach($country as $country)
<option value="{{$country->id}}">{{$country->name}}</option>
@endforeach
</select>
</div>

</div>

<div class="row">

<div class="col-lg-4 col-md-4 col-sm-4">
<p>State</p>
</div>
<div class="col-lg-8 col-md-8 col-sm-8">
<select name="location" onchange="getCountryStateCity({location_id:this.value,location_type:2}, 'city')" id="state" required/></select>
</div>

</div>


<div class="row">

<div class="col-lg-4 col-md-4 col-sm-4">
<p>City</p>
</div>
<div class="col-lg-8 col-md-8 col-sm-8">
<select name="city" id="city" required/></select>
</div>

</div>
</form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript">
			function getCountryStateCity(data, loadDataToDiv) {
				$("#"+loadDataToDiv).html('<option selected="selected">-- -- -- Loading Data -- -- --</option>');
				if(loadDataToDiv=='state'){
					$('#city').html('');
					$('#state').html('');
				}
				if(loadDataToDiv=='city'){
						$('#city').html('');
				}
				$.get("{{route('ajaxCall')}}", data, function(result) {
						$('#' + loadDataToDiv).html(result);
				});
			}
</script>

</body>
</html>