<!DOCTYPE HTML>
<html>
    <head>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
        <script src="{{asset('public/js/TimeCircles.js')}}"></script>
      <link rel="stylesheet" href="{{ asset('public/js/TimeCircles.css') }}">

    </head>
    <body>
            <div id="CountDownTimer" data-timer="60" style="width: 300px; height: 200px;"></div>


        <script>
            $("#CountDownTimer").TimeCircles({ time: { Days: { show: false }, Hours: { show: false } }});



        </script>
    </body>
</html>