@extends('master')


@section('content')
    <style type="text/css">
    html   
{   
    background: #d0cec9;   
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#dedcd9', endColorstr='#f7f7f6');   
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0, #dedcd9),      
    color-stop(0.1, #f7f7f6), color-stop(1.0, #f7f7f6));   
    background: -moz-linear-gradient(top, #dedcd9 0px, #f7f7f6 400px, #f7f7f6 100%);   
}   

#shadow  
{  
    position: fixed;  
    top: -10px;  
    left: 0;  
    width: 100 % ;  
    height: 10px;  
    box - shadow: 0px 0px 7px rgba(0, 0, 0, .2); - moz - box - shadow: 0px 0px 7px rgba(0, 0, 0, .4); - webkit - box - shadow: 0px 0px 7px rgba(0, 0, 0, .2);  
    z - index: 2;  
}  
#bars  
{  
    width: 100 % ;  
    height: 42px;  
    margin - top: -20px;  
}  
#bars div   
{  
    position: relative;  
    float: left;  
    width: 54px;  
    height: 100 % ;  
    margin - right: 55px;  
    box - shadow: 0px 2px 5px rgba(0, 0, 0, .35); - moz - box - shadow: 0px 2px 5px rgba(0, 0, 0, .35); - webkit - box - shadow: 0px 2px 5px rgba(0, 0, 0, .35);  
}  
#bars div.n  
{  
    background: #2e78bc; }   
# bars div.m  
{  
    background: #a3be48;      
      
}  
    #bars div.c   
    {  
        background: #9a9a9a; margin: 0;   
          
    } 
    </style>  
    <body>  
        <div id="container">  
            <header role="banner">  
                <h1>  
                    <a href="/">My BLog</a>  
                </h1>  
            </header>  
            <nav>  
                <ul>  
                    <!-- nav items -->  
                </ul>  
            </nav>  
            <div id="blog" class="hidden"> 
            </div>  
            <!-- blog -->
          
            <article>  
                <header>
                    <h1>  
                        <a href="{{route('viewblog',$blog->slug)}}">{{$blog->title}}</a>  
                    </h1> 
                    <div class="blog">  
                        <img src="{{url('/')}}/public/uploads/{{$blog->image}}" width="150px"> 
                    </div> 
                    <div class="des">
                    <p>{{$blog->description}}</p>

                    </div>
                </header>  
            </article>
            @foreach($commt as $comt )
            <div>
                <p>{{$comt->comment}}{{ $comt->id}}</p>


            </div>
            @endforeach

            <div class="commentsection">
             <form method="post" action="{{route('viewblog')}}">
                @include('flash::message')
                Name:<br>
                <input type="text"  name="name" value="">
                <br><br>
                Message:<br>
                <textarea cols="40" rows="4" name="comment" value=""></textarea>
                <br><br>
                <input type="hidden" value="{{$blog->id }}" name="blog_id">
                <input type="hidden" value="{{\Request::path()}}" name="url">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <input type="submit" value="Submit">
                </form> 
            </div>

        <!-- container -->  
        <!-- scripts -->  
@endsection