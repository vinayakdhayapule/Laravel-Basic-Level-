<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Itdukaan.com</title>
</head>

<body>



<table width="610" border="0" align="center" cellpadding="0" cellspacing="0" style="font-family:Roboto Condensed;">
    <!--app icon download strip-->
    <tr>
        <td>&nbsp;</td>
    </tr>
    <!-- End app icon download strip-->

    <!--Logo and Menu Section-->
    <tr>
        <td>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="34%" align="left"><a href="#"><img src="http://itdukaan.com/public/logo.png" alt="itdukaan.com" style="border: 0px none; width: 183px;"></a></td>
                    <td width="66%">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td style="text-align: right; padding: 5px 0px; border-bottom: 3px solid rgb(109,188,219); background-color:rgb(244,244,244); "><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="60%" align="right"><span><a href="#" style="border-right: 0px solid rgb(204, 204, 204); margin-right: 0px; padding-right: 0px; text-decoration: none; color: rgb(0, 0, 0); font: 12px/16px arial,sans-serif;" target="_blank">www.ITDukaan.com</a></span></td>
                                            <td width="7%" align="right"><span style="text-decoration: none; color: rgb(204, 204, 204); font-size: 15px; font-family: arial,sans-serif;">&nbsp;|&nbsp;</span></td>
                                            <td width="8%" align="right"><img src="http://itdukaan.com/public/images/mobile_icon.png" alt="itdukaan.com" style="border: 0px none; width: 8px;" /></td>
                                            <td width="25%" align="right"><span><a href="#" style="border-right: 0px solid rgb(204, 204, 204); margin-right: 0px; padding-right: 0px; text-decoration: none; color: rgb(0, 0, 0); font: 12px/16px arial,sans-serif;" target="_blank">Download App</a></span></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>

                    </td>
                </tr>
            </table>

        </td>
    </tr>
    <!-- End Logo and Menu Section-->

    <!--order msg Section-->


    <tr>
        <td>
      
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td align="right">
                        <h2 style="font-size: 21px; line-height: 30px; margin: 0px; padding: 0px; font-weight: normal; color: rgb(0, 0, 0) ! important; font-family: Roboto Condensed;"></h2>
                        <span><a href="#" style="text-decoration: none; font-size: 20px; color: rgb(0, 0, 0); font-family: Roboto Condensed;" target="_blank"></a></span> <br /><br /><br /></td>
                </tr>
                <tr>
                    <td>
                        <h2 style="font-size: 20px; line-height: 24px; margin: 0px; padding: 0px; font-family: Roboto Condensed; font-weight: normal; color: rgb(109,188,219) ! important;">Hi {{$name}} </h2>
                        <p>Thanks for Subscribing Newsletter</p>
                        <p>Get started on a simple and incredible experience on ITDukaan. You can use ITDukaan to recharge your mobile or DTH, pay your bills or shop online!</p>
                        
                        <p><a href="#" style="text-decoration:none; color:rgb(109,188,219);font-family: Roboto Condensed;">Click here</a> to verify your email address and enjoy additional security in your ITDukaan account.</p>
                        <p>Should you need any further assistance, contact us at <a href="#" style="text-decoration:none; color:rgb(109,188,219);font-family: Roboto Condensed;">care@ITDukaan.com</a></p>
                        <p>Look forward to see you again at ITDukaan.</p>
                        <p>ITDukaan Care Team</p>
                        <p>If you did not create this account on ITDukaan and you think someone else has used your Email ID to create an account, please remove your Email ID from this account by <a href="#" style="text-decoration:none; color:rgb(109,188,219);font-family: Roboto Condensed;">clicking here</a>.</p>

                    </td>
                </tr>
            </table>
         

        </td>
    </tr>

    <tr>
        <td style="height:50px;"></td>
    </tr>
    <!-- Nihar Market Peoducts Details Section-->
    <tr>
        <td style="text-align: left; height:20px; vertical-align:bottom; padding:0px 0px; border-bottom: 2px solid rgb(239, 239, 239);">
            <span style="background-color:rgb(239, 239, 239); display:block;width:130px;  padding:10px; font-size:16.5px; color:#000; font-family:Roboto Condensed;">NIHAR MARKET</span>
        </td>
    </tr>

    <tr>
        <td align="center">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td height="20px"></td>
                </tr>
                <tr>
                    <td align="center"><span><a href="http://www.goldnsilver.in/"><img src="http://itdukaan.com/public/images/goldnsilver_logo.png" alt="Goldnsilver.in" style="border: 0px none;" title="www.goldnsilver.in"></a></span></td>
                    <td align="center"><span><a href="www.makeadeal.in"><img src="http://itdukaan.com/public/images/makeadeal_logo.png" alt="Makeadeal.in" style="border: 0px none;" title="http://www.makeadeal.in/"></a></span></td>
                    <td align="center"><span><a href="http://www.anyservice.in/"><img src="http://itdukaan.com/public/images/anyservice_logo.png" alt="www.anyservice.in" style="border: 0px none;" title="Anyservice"></a></span></td>
                    <td align="center"><span><a href="http://www.cinescope.in/"><img src="http://itdukaan.com/public/images/cinescope_logo.png" alt="Cinescope.in" style="border: 0px none;" title="www.cinescope.in"></a></span></td>
                </tr>
                <tr>
                    <td height="5px"></td>
                </tr>
                <tr>
                    <td align="center"><span><a href="http://www.banyanstore.com/"><img src="http://itdukaan.com/public/images/banyanstore_logo.png" alt="Banyanstore.in" style="border: 0px none;" title="www.banyanstore.com"></a></span></td>
                    <td align="center"><span><a href="http://www.smartmelody.in/"><img src="http://itdukaan.com/public/images/smartmelody_logo.png" alt="Smartmelody.in" style="border: 0px none;" title="www.smartmelody.in"></a></span></td>
                    <td align="center"><span><a href="http://itdukaan.com/"><img src="http://itdukaan.com/public/images/itdukaan_logo.png" alt="ITDukaan.in" style="border: 0px none;" title="www.itdukaan.com"></a></span></td>

                </tr>
            </table>

        </td>
    </tr>
    <!-- End Nihar Market Peoducts Details Section-->
    <tr>
        <td height="35px"></td>
    </tr>
    <tr>
        <td style="text-align: left; padding: 5px 0px; border-bottom: 3px solid rgb(109,188,219); background-color:rgb(244,244,244);">

            <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="2" style="font-size:21px; color:#000; font-family:Roboto Condensed; line-height:45px;">Any Questions?</td>
                </tr>
                <tr>
                    <td width="7%"><img src="http://itdukaan.com/public/images/phone_icon.png" alt="call" style="border: 0px none;"></td>
                    <td width="93%" style="font-size:30px; color:#000; font-family:Roboto Condensed; line-height:50px; " >+91 7799636636</td>
                </tr>
                <tr>
                    <td><img src="http://itdukaan.com/public/images/mail_icon.png" alt="call" style="border: 0px none;"></td>
                    <td style="font-size:16.5px; color:#000; font-family:Roboto Condensed; line-height:30px; ">support@itdukaan.com,  support@niharmarket.com</td>
                </tr>
            </table>

        </td>
    </tr>

    <tr>
        <td style="font-size:10.5px; color:#000; font-family: arial, sans-serif; line-height:30px; ">This email was sent from a notification-only address that cannot accept incoming email. Please do not reply to this message.</td>
    </tr>

    <tr>
        <td>&nbsp;</td>
    </tr>

    <tr>
        <td>&nbsp;</td>
    </tr>
</table>
</body>
</html>