@extends('layouts.app')

@section('content')
{{ $success = Session::get('success') }}
@if($success)
    <div class="alert-box success">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <h2>{{ $success }}</h2>

    </div>
@endif
    <div class="container">
        <div class="col-sm-3">
            <div id="CountDownTimer" data-timer="10" style="width: 300px; height: 200px;"></div>
        </div>
        <div class="col-sm-9">
            @include('flash::message')
                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!-- New Task Form -->
                    <form action="{{route('postquizanswer')}}" method="POST" class="form-horizontal" id="submitquiz">
                        {{ csrf_field() }}
                        <!-- Task Name -->
                        <div class="form-group">
                            @foreach($question as $question)
                        <p class="question">{{$question->id}}){{$question->question}}</p>
                <input type="hidden" name="question_id[]" value="{{$question->id}}">

                        <ul class="answers">
                        @foreach($question->naresh as $answer)
                        <li style="list-style: none;">
                <input type="radio" name="answer_id[{{$question->id}}]" value="{{$answer->id}}"><label >{{$answer->answer}}</label></li>
                            @endforeach
                        </ul>

                        @endforeach
                            </div>
                            <div class="col-sm-offset-3 col-sm-3">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>submit
                                </button>
                            </div>


                        </div>
                    </form>
                </div>


    <script>
            $("#CountDownTimer").TimeCircles({ time: { Days: { show: false },Minutes: { show: false } , Hours: { show: false }, direction: "Both" }});

            window.setInterval(function(){
                if($(".textDiv_Seconds > span").text() == 0)
                {
                    $("#CountDownTimer").TimeCircles().stop();
                    $("#submitquiz").submit();
                }
            }, 1000);



        </script>

@endsection
