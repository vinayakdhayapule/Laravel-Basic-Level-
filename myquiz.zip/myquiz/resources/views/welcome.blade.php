@extends('layouts.app')

@section('content')
{{ $success = Session::get('success') }}
@if($success)
    <div class="alert-box success">
        <h2>{{ $success }}</h2>
    </div>
@endif
    <div class="container">
        <div class="col-sm-6 col-sm-6">
            @include('flash::message')
                <div class="panel-body">
                     <div class="row">
  <div class="col-sm-8"><div class="list-group">
  <a href="#" class="list-group-item active">
   Index
  </a>
  <a href="{{route('register')}}" class="list-group-item">Sign UP</a>
  <a href="{{route('login')}}" class="list-group-item">Login</a>

  <a href="#" class="list-group-item">Vestibulum at eros</a>
</div></div>

                </div>
                </div>
        </div>
    </div>
@endsection
