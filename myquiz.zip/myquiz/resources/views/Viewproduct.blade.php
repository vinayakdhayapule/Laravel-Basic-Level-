<!DOCTYPE html> <html> <head>     <title>View Product</title>     <style
type="text/css">       ul.products p {     width: 20px;     margin-left: 35px;
margin-top: 35px; } ul.products li h4 {     font-size: 19px;     font-style:
italic;     color: #36363E;     margin-top: 32px; } ul.products li {
display: inline-flex; } button.compare {     margin-left: 48px;     height:
31px;     width: 72px;     border-radius: 4px;     margin-top: 31px;
color: white;     background-color: #e74430;     border-color: #e74430;
font-size: 15px;     font-weight: 700; } </style> </head>
<body>
<a href="{{route('compare-list')}}">Compare</a>
@foreach($product as $product)
<ul class="products">
		<li>
			<h4>{{$product->product_name}}</h4>
			<p>{{$product->id}}</p>
			<p>{{$product->price}}</p>
			<p>{{$product->slug}}</p>
			<button data-id = "{{$product->id}}" class="compare">Add</button>
		</li>
</ul>
@endforeach
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.compare').click(function(){
        var id = $(this).data('id');
        var token = $('#token').val();
        var data = {"id": id, "_token": "{{ csrf_token() }}"};
        $.ajax({
            url : 'add-to-compare',
            type: 'POST',
       		data: data,
            success : function(response){
            	console.log(response);
                if(response == 0)
                {
                	alert('product already exist');
                }
                else if(response == 1)
                {
                	alert('product added successfully');
                }
            }
        });
    });
});
</script>

</body>
</html>