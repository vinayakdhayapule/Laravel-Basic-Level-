@extends('layouts.app')

@section('content')
{{ $success = Session::get('success') }}
@if($success)
    <div class="alert-box success">
        <h2>{{ $success }}</h2>
    </div>
@endif
    <div class="container">
        <div class="col-sm-6 col-sm-6">
            @include('flash::message')
                <div class="panel-body">
                    <!-- Display Validation Errors -->
                    <!-- New Task Form -->
                    <form action="{{route('postCategory')}}" method="POST" class="form-horizontal">
                        {{ csrf_field() }}
                        <!-- Task Name -->
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Category Name</label>
                            <div class="col-sm-6">
                            <input type="text" name="category_name" id="task-name" class="form-control" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Meta Title</label>
                            <div class="col-sm-6">
                            <input type="text" name="meta_title" id="task-name" class="form-control" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Meta Description</label>
                            <div class="col-sm-6">
                            <input type="text" name="meta_desc" id="task-name" class="form-control" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" class="form-control">
                            </div>
                        </div>
                        <!-- Add Task Button -->
                        <!-- <div class="form-group"> -->
                            <div class="col-sm-offset-3 col-sm-3">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>submit
                                </button>
                            </div>
                        <!-- </div> -->
                    </form>
                </div>
                </div>
        </div>
    </div>
@endsection
