<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegisterQuiz extends Model {

	protected $table = 'registerquiz';
	protected $fillable = ['user_id', 'name', 'email', 'code', 'status'];
}
