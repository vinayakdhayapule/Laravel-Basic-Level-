<?php

namespace App;
use Cviebrock\EloquentSluggable\SluggableInterface;
use Cviebrock\EloquentSluggable\SluggableTrait;
use Illuminate\Database\Eloquent\Model;

class Product extends Model implements SluggableInterface {
	use SluggableTrait;

	protected $table = "product";
	protected $fillable = ['product_name', 'slug', 'price'];
	protected $sluggable = [
		'build_from' => 'product_name',
		'save_to' => 'slug',
	];
}