<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compare extends Model {
	protected $table = "compare";
	protected $fillable = ['token', 'product_id'];
}
