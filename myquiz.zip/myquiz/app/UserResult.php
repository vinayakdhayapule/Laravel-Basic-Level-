<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserResult extends Model {
	protected $table = 'user_result';
	protected $fillable = ['answer_id', 'question_id', 'user_id'];

}
