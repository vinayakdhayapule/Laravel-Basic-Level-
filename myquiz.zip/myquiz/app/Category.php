<?php

namespace App;


use Cviebrock\EloquentSluggable\SluggableInterface;
use Cviebrock\EloquentSluggable\SluggableTrait;
use Baum\Node;


use Illuminate\Database\Eloquent\Model;

class Category extends Node implements SluggableInterface
{
    use SluggableTrait;

    protected $table = "categories";
    protected $fillable =['category_name','slug','meta_title','meta_desc'];
    protected $sluggable = [
		'build_from' => 'category_name',
		'save_to' => 'slug',
	];
}
