<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
 */

Route::get('/', function () {
	return view('welcome');
});
/* Backend Starts*/

Route::get('role', 'RoleController@getRole');
Route::post('role', ['as' => 'CreateRole', 'uses' => 'RoleController@CreateRole']);

Route::get('register', ['as' => 'register', 'uses' => 'RegisterController@getRegister']);
Route::post('register', ['as' => 'doregister', 'uses' => 'RegisterController@doregister']);

Route::get('login', ['as' => 'login', 'uses' => 'RegisterController@getlogin']);
Route::post('login', ['as' => 'dologin', 'uses' => 'RegisterController@dologin']);
Route::get('profile', ['as' => 'profile', 'uses' => 'RegisterController@getProfile']);

Route::group(['middleware' => 'backend'], function () {

	Route::get('welcome', ['as' => 'welcome', 'uses' => 'RegisterController@getWelcome']);
	Route::get('logout', ['as' => 'logout', 'uses' => 'RegisterController@getLogout']);

	/*Quiz Controller*/

	Route::get('quiz', ['as' => 'quiz-form', 'uses' => 'QuizController@getQuizForm']);
	Route::post('quiz', ['as' => 'post-quiz', 'uses' => 'QuizController@postQuizForm']);
	Route::get('verify/{code}/{id}', ['as' => 'verify', 'uses' => 'QuizController@quizCode']);
	Route::get('test', ['as' => 'test', 'uses' => 'QuizController@getquiz']);
	Route::post('test', ['as' => 'postquizanswer', 'uses' => 'QuizController@postquizanswer']);

});

Route::get('blog', 'BlogController@Blogpage');
Route::post('blog', ['as' => 'CreateBlog', 'uses' => 'BlogController@CreateBlog']);
Route::get('showblog', 'BlogController@ShowBlog');
Route::get('viewblog/{slug}', ['as' => 'viewblog', 'uses' => 'BlogController@viewBlog']);
Route::post('viewblog/{slug}', ['as' => 'viewblog', 'uses' => 'BlogController@commemtblog']);

Route::get('location', 'LocationController@showLocation');
Route::get('ajaxCall', ['as' => 'ajaxCall', 'uses' => 'LocationController@ajaxCall']);

/* Backend ends*/

/* test Starts*/

Route::get('create', ['as' => 'create', 'uses' => 'CategoryController@createRoot']);
Route::post('postcreate', ['as' => 'postcreate', 'uses' => 'CategoryController@postCreateRoot']);
Route::post('postSubCategory', ['as' => 'postSubCategory', 'uses' => 'CategoryController@postSubCategory']);

Route::get('category', ['as' => 'createCategory', 'uses' => 'CategoryController@getCreateCategory']);
Route::post('category', ['as' => 'postCategory', 'uses' => 'CategoryController@postCreateCategory']);

Route::get('newsletter', ['as' => 'getnewsletter', 'uses' => 'NewsletterController@getViewSubscribers']);
Route::post('postnewsletter', ['as' => 'postnewsletter', 'uses' => 'NewsletterController@postSubscribe']);

Route::get('product', ['as' => 'product', 'uses' => 'ProductController@viewProducts']);
Route::post('add-to-compare', ['as' => 'add-to-compare', 'uses' => 'ProductController@addToCompare']);
Route::get('compare-list', ['as' => 'compare-list', 'uses' => 'ProductController@compareList']);

Route::get('search', ['as' => 'search', 'uses' => 'ProductController@productSearch']);
Route::post('search', ['as' => 'post-search', 'uses' => 'ProductController@postProductSearch']);
Route::get('rating', ['as' => 'getRating', 'uses' => 'ProductController@getRating']);
Route::post('rating', ['as' => 'postRating', 'uses' => 'ProductController@postRating']);

Route::get('feedback', ['as' => 'getFeedback', 'uses' => 'ProductController@getFeedback']);

/* test ends*/

Route::get('task', 'TaskController@showTask');
Route::post('task', ['as' => 'create-task', 'uses' => 'TaskController@createTask']);
Route::post('delete-task', ['as' => 'delete-task', 'uses' => 'TaskController@deleteTask']);
