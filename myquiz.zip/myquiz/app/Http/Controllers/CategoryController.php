<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Controllers\Controller;
use App\SubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class CategoryController extends Controller {

	public function createRoot() {
		$sub = SubCategory::getNestedList('name', null, '-');
		return view('create', compact('sub'));
	}

	public function postCreateRoot(Request $request) {
		$root = SubCategory::create([
			'name' => $request->get('name')]);
		$root->makeRoot();
		return redirect()->back();
	}

	public function postSubCategory(Request $request) {
		$root = SubCategory::find($request->get('id'));
		$category = SubCategory::create([
			'name' => $request->get('sub_name')]);
		$category->makeChildOf($root);
		return redirect()->back();
	}

	public function getCreateCategory() {
		return view('category');
	}

	public function postCreateCategory(Request $request) {
		// dd($request->all());
		$category = Category::create([
			'category_name' => $request->get('category_name'),
			'meta_title' => $request->get('meta_title'),
			'meta_desc' => $request->get('meta_desc'),
		]);
		$category->makeRoot();
		return redirect()->back();

	}
}
