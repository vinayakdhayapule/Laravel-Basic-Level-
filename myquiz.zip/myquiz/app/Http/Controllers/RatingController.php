<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Rating;
use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Illuminate\Http\Request;

class RatingController extends Controller {

	public function getRating() {
		return view('rating');
	}

	public function postRating(Request $request) {

		if (Sentinel::check()) {
			$user_id = Sentinel::getUser()->id;
			$rating = Rating::create([
				'user_id' => $user_id,
				'rating' => $request->get('rating'),
			]);
			flash()->success('rating Added ');
			return redirect()->intended('rating');

		} else {
			flash()->success('You are not loggedin, please Log in to continue..');
			return redirect()->route('login');
		}

	}

}
