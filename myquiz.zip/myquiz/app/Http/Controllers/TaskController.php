<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Task;
use Illuminate\Http\Request;

class TaskController extends Controller {

	public function showTask() {
		$task = Task::all();
		$int = rand(0, 25);
		$int1 = rand(0, 25);
		$a_z = "abcdefghijklmnopqrstuvwxyz";
		$a_z1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$str = rand(10, 99) . $a_z[$int] . $a_z1[$int1] . rand(0, 9) . $a_z[$int];
		return view('tasks', compact('task', 'str'));
	}

	public function createTask(Request $request) {
		if (($request->str) == $request->result) {
			$task = Task::create([
				'name' => $request->get('name'),
			]);
		}
		return redirect()->back();
	}

	public function deleteTask(Request $request) {
		$task = Task::find($request->get('id'))->delete();

		return redirect()->back()->withInput()->with('success', 'Group deleted Successfully.');

	}
}