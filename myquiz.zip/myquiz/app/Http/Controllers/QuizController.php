<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Question;
use App\RegisterQuiz;
use App\UserResult;
use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class QuizController extends Controller {

	public function getQuizForm() {
		$user = RegisterQuiz::whereUserId(Sentinel::getUser()->id)->whereStatus(1)->get()->first();
		return view('quizregister', compact('user'));
	}

	public function postQuizForm(Request $request) {
		$user_exist = RegisterQuiz::whereUserId(Sentinel::getUser()->id)->get()->first();
		$code = uniqid();
		if (Sentinel::check() && !$user_exist) {
			$data = RegisterQuiz::create([
				'user_id' => Sentinel::getUser()->id,
				'name' => $request->get('name'),
				'email' => $request->get('email'),
				'code' => $code,
				'status' => 0,
			]);

			if ($data) {
				Mail::send('emailtemplate.statusapproval', ['user' => $data], function ($m) use ($data) {
					$m->from('hello@app.com', 'Your Application');
					$m->to($data->email, $data->name)->subject('Your Reminder!');
				});
				flash()->message('Status -> Pending Approval');
				return redirect()->back();
			} else {
				flash()->message('Something Went Wrong');
				return redirect()->back();
			}

		} else {
			flash()->message('Something Went Wrong');
			return redirect()->back();
		}
	}

	public function quizCode($code, $id) {
		$qid = RegisterQuiz::whereUserId($id)->whereCode($code)->get()->first();
		$user = RegisterQuiz::find($qid->id);
		$user->status = 1;
		if ($user->save()) {
			flash()->message('Status -> approved');
			return redirect()->route('quiz-form');
		}

	}
	public function getquiz() {
		$question = Question::get();
		return view('test', compact('question'));
	}
	public function postquizanswer(Request $request) {
		// dd($request->all());
		for ($i = 0; $i < count($request->get('question_id')); $i++) {
			if (!UserResult::whereQuestionId($request->get('question_id')[$i])->whereUserId(Sentinel::getUser()->id)->get()->first()) {
				UserResult::create([
					'user_id' => Sentinel::getUser()->id,
					'answer_id' => $request->get('answer_id')[$i + 1],
					'question_id' => $request->get('question_id')[$i],
				]);

			} else {
				flash()->warning('already done!!');
				return redirect()->route('quiz-form');
			}
		}
		flash()->success('done!');
		return redirect()->route('quiz-form');
	}

}
