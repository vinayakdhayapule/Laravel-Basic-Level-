<?php 

/**
* 
*/
class CommentDisplay 
{
	
private $type;
private $user;
public function __construct($type) {
$this->user = Sentinel::getUser();
}

public function comment() {
$blog = Comment::create([
'blog_id' => session('blog_id'),
'comment' => session('comment'),
]);
if ($blog->id) {
flash()->success('Comment posted Successfully.');
} else {
flash()->error('Unable to post the Comment. Please try again.');
}

$this->resetSessionVaraiables();
}

?>
