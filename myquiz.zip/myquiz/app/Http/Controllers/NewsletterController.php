<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Subscribe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class NewsletterController extends Controller {
	public function getViewSubscribers() {
		return view('subscribe');
	}

	public function postSubscribe(Request $request) {
		$subscribe = Subscribe::create([
			'name' => $request->get('name'),
			'email' => $request->get('email'),
		]);

		$user = [
			'email' => $request->get('email'),
			'name' => $request->get('name'),
		];

		$data = [
			'email' => $request->get('email'),
			'name' => $request->get('name'),
		];

		Mail::send('newsletter', $data, function ($message) use ($user) {
			$message->from('info@vinayk.com', 'Dhayapule')->to($user['email'])->subject('subscription');
		});

		return redirect()->back();

	}

	public function store(Request $request) {
		//
	}

	public function show($id) {
		//
	}
	public function FunctionName($value = '') {

	}

}
