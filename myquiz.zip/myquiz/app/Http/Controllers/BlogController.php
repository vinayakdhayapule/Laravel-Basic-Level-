<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Blog;
use App\Comment;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Cartalyst\Sentinel\Native\Facades\Sentinel;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
 
   public function Blogpage() {
   
       return view('addblog');
   }

   /**
     * creating the New Blog.
     *
     * @return \Illuminate\Http\Response
     */

    public function CreateBlog(Request $request){  
                  
      $blogs = New Blog();
        $blogs->title = $request->get('title');
        $blogs->description = $request->get('description');
        if ($request->hasFile('image')){
          $image = $request->file('image');
          $filename = $image->getClientOriginalName();
          $image->move(strstr(public_path(),'public/') . 'public/uploads', $filename);
          $blogs->image = $filename;
          $blogs->save();
          }
        else { $blogs->save(); }

      if ($blogs) {
     flash()->success('sucessfully blog has been posted');
        return redirect()->back();
    } else {
      flash()->error('unsucessful something went wrong');
        return redirect()->back();
           }
    }

    public function ShowBlog() {
      $blogs = Blog::all();
      return view('myblog', compact('blogs'));
    }

    public function viewBlog($slug) {
      $blog = Blog::whereSlug($slug)->first();
      $commt = Comment::whereBlogId($blog->id)->whereCommentStatus(1)->get();
     return view('singleblog', compact('blog','commt'));
    }

public function commemtblog(Request $request)
{      
      if (Sentinel::check()) {
      $commt = Comment::create([
      'blog_id' => $request->get('blog_id'),
      'comment' => $request->get('comment'),
      'comment_status' => '0'
    ]);
          if ($commt) {
           flash()->success('sucessfully comment has been posted');
              return redirect()->back(); } 
          else {
            flash()->error('unsucessful something went wrong');
              return redirect()->back(); }
       }else {

            session(['blog_id' => $request->get('blog_id')]);
            session(['comment' => $request->get('comment')]);
            session(['return_url' => $request->get('url')]);
            session(['type' => 'comment']);

            flash()->info('You are not loggedin, please Log in to continue..');
            return redirect()->route('login');

      }
}
  }

