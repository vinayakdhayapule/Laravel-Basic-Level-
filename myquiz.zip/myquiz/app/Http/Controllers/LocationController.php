<?php namespace
App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Location;
use Illuminate\Http\Request;

class LocationController extends Controller {
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function showLocation() {
		$country = Location::whereParentId(0)->get();
		return view('address', compact('country'));

	}

	public function ajaxCall(Request $request) {

		$location_id = $request->get('location_id');
		$location_type = $request->get('location_type');
		$types = array('country', 'State', 'City');

		$obj = Location::whereParentId($location_id)->whereLocationType($location_type)->orderBy('name')->get();
		$option = '';
		$option .= '<option value="">Select ' . $types[$location_type] . '</option>';
		foreach ($obj as $value) {
			if ($request->has('state')) {
				$selected = $value->id == $request->get('state') ? 'selected' : '';
				$option .= '<option value="' . $value->id . '"' . $selected . '>' . $value->name . "</option>";
			} elseif ($request->has('city')) {
				$selected = $value->id == $request->get('city') ? 'selected' : '';
				$option .= '<option value="' . $value->id . '"' . $selected . '>' . $value->name . "</option>";
			} else {
				$option .= "<option value='" . $value->id . "'>" . $value->name . "</option>";
			}
		}
		return $option;
	}
}
