<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Product;
use App\Rating;
use App\Search;
use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Illuminate\Http\Request;

class ProductController extends Controller {
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function viewProducts() {
		// dd('abc');
		$product = Product::all();
		return view('Viewproduct', compact('product'));

	}
	public function addToCompare(Request $request) {
		// $request->session('pid')->flush();
		if ($request->session()->has('pid')) {
			if (in_array($request->id, \Session::get('pid'))) {
				return 0;
			}
		}
		\Session::push('pid', $request->id);
		return 1;
	}

	public function compareList() {
		$id = \Session::get('pid');
		$products = Product::whereIn('id', $id)->get();
		return view('chat', compact('products'));

	}

	public function api() {
		$arr = ['name' => 'vinayak', 'designation' => 'software engineer'];
		return json_encode($arr);
	}

	public function accessApi() {
		$response = \Laracurl::get('http://localhost/test/api');
		$response = json_decode($response);
		dd($Response);
	}

	public function productSearch() {
		$article = '';
		return view('search', compact('article'));
	}

	public function postProductSearch(Request $request) {
		$sql = "select * from search where stock = 1";
		if (!empty($request->get('name'))) {
			$name = '%' . $request->get('name') . '%';
			$sql .= " AND product_name LIKE '$name'";
		}
		if (!empty($request->get('min') && $request->get('max'))) {
			$min = $request->get('min');
			$max = $request->get('max');
			$sql .= " AND price Between $min AND $max";
		}
		$product = collect(\DB::select(\DB::raw($sql)))->lists(['id']);
		// dd($product);
		$article = Search::whereIn('id', $product)->get();
		// dd($article);
		return view('search', compact('article'));
	}

	public function getRating() {
		return view('rating');
	}

	public function postRating(Request $request) {

		if (Sentinel::check()) {
			$user_id = Sentinel::getUser()->id;
			$rating = Rating::create([
				'user_id' => $user_id,
				'rating' => $request->get('rating'),
			]);
			flash()->success('rating Added ');
			return redirect()->intended('rating');

		} else {
			flash()->success('You are not loggedin, please Log in to continue..');
			return redirect()->route('login');
		}

	}
	public function getFeedback() {
		return view('feedback');
	}

	public function postFeedback(Request $request) {
		if (!empty($request->get('email'))) {
			$data = [
				'email' => $request->get('email'),
				'name' => $request->get('name'),
				'feedback_message' => $request->get('feedback_message'),
			];
			Mail::queue('emailtemplate.feedback', $data, function ($message) use ($data) {
				$message->from($data['email'], $data['name'])->to('support@vinayak.com')->subject('Customer Feedback');
			});
			return redirect()->back();
		} else {
			return '2';
		}
	}

}
