<?php namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Role;
use Cartalyst\Sentinel\Native\Facades\Sentinel;

class RoleController extends Controller
{
    
    public function getRole()
    {
        //
        $roles =Role::all();
        return view('roles');

    }

    public function CreateRole(Request $request)
    {
        
        $role = Sentinel::getRoleRepository()->createModel()->create([
                'name' => $request->get('creatrole'),
                'slug' => str_slug($request->get('creatrole')),

        ]);

        flash()->success('sucessfully role has been created');
        return redirect()->back();


    }

   
}
