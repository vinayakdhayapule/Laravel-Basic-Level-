<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
 */
get('api', 'ProductController@api');
get('getapi', 'ProductController@accessApi');

Route::get('/', function () {
	return view('welcome');
});

Route::get('role', 'RoleController@getRole');
Route::post('role', ['as' => 'CreateRole', 'uses' => 'RoleController@CreateRole']);
Route::get('register', 'RegisterController@getRegister');
Route::post('register', ['as' => 'doregister', 'uses' => 'RegisterController@doregister']);

Route::get('login', ['as' => 'login', 'uses' => 'RegisterController@getlogin']);
Route::post('login', ['as' => 'dologin', 'uses' => 'RegisterController@dologin']);
Route::get('profile', ['as' => 'profile', 'uses' => 'RegisterController@getProfile']);

Route::group(['middleware' => 'backend'], function () {

	Route::get('welcome', ['as' => 'welcome', 'uses' => 'RegisterController@getWelcome']);

	Route::get('logout', ['as' => 'logout', 'uses' => 'RegisterController@getLogout']);
	// Route::get('rating', ['as' => 'getRating', 'uses' => 'RatingController@getRating']);
	// Route::post('rating', ['as' => 'postRating', 'uses' => 'RatingController@postRating']);

});

Route::get('blog', 'BlogController@Blogpage');
Route::post('blog', ['as' => 'CreateBlog', 'uses' => 'BlogController@CreateBlog']);
Route::get('showblog', 'BlogController@ShowBlog');
Route::get('viewblog/{slug}', ['as' => 'viewblog', 'uses' => 'BlogController@viewBlog']);
Route::post('viewblog/{slug}', ['as' => 'viewblog', 'uses' => 'BlogController@commemtblog']);

Route::get('location', 'LocationController@showLocation');
Route::get('create', ['as' => 'create', 'uses' => 'LocationController@createRoot']);
Route::post('postcreate', ['as' => 'postcreate', 'uses' => 'LocationController@postCreateRoot'])

// Route::get('rating', ['as' => 'getRating', 'uses' => 'RatingController@getRating']);
// Route::post('rating', ['as' => 'postRating', 'uses' => 'RatingController@postRating']);

Route::get('task', 'TaskController@showTask');
Route::post('task', ['as' => 'create-task', 'uses' => 'TaskController@createTask']);
Route::post('delete-task', ['as' => 'delete-task', 'uses' => 'TaskController@deleteTask']);


Route::post('postSubCategory', ['as' => 'postSubCategory', 'uses' => 'LocationController@postSubCategory']);

Route::get('category', ['as' => 'createCategory', 'uses' => 'CategoryController@getCreateCategory']);
Route::post('category', ['as' => 'postCategory', 'uses' => 'CategoryController@postCreateCategory']);

Route::get('newsletter', ['as' => 'getnewsletter', 'uses' => 'NewsletterController@getViewSubscribers']);
Route::post('postnewsletter', ['as' => 'postnewsletter', 'uses' => 'NewsletterController@postSubscribe']);
Route::get('product', ['as' => 'product', 'uses' => 'ProductController@viewProducts']);
Route::post('add-to-compare', ['as' => 'add-to-compare', 'uses' => 'ProductController@addToCompare']);
Route::get('compare-list', ['as' => 'compare-list', 'uses' => 'ProductController@compareList']);
Route::get('search', ['as' => 'search', 'uses' => 'ProductController@productSearch']);
Route::post('search', ['as' => 'post-search', 'uses' => 'ProductController@postProductSearch']);
// Route::get('profile', ['as' => 'getprofile', 'uses' => 'ProfileController@getProfile']);
Route::get('rating', ['as' => 'getRating', 'uses' => 'ProductController@getRating']);
Route::post('rating', ['as' => 'postRating', 'uses' => 'ProductController@postRating']);
Route::get('feedback', ['as' => 'getFeedback', 'uses' => 'ProductController@getFeedback']);
