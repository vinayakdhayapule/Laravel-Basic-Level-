<?php

namespace App;

use Baum\Node;

class SubCategory extends Node {
	protected $table = 'subcategory';
	protected $fillable = ['name'];
}
