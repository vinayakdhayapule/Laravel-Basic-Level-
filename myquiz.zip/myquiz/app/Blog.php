<?php

namespace App;
use Cviebrock\EloquentSluggable\SluggableInterface;
use Cviebrock\EloquentSluggable\SluggableTrait;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model implements SluggableInterface
{
    use SluggableTrait;

    protected $table= 'blogs';
    protected $fillable = ['title','slug','description', 'image'];
    protected $sluggable = [
        'build_from' => 'title',
        'save_to'    => 'slug',
    ];
}
