-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2016 at 03:51 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `creative`
--

-- --------------------------------------------------------

--
-- Table structure for table `activations`
--

CREATE TABLE `activations` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `activations`
--

INSERT INTO `activations` (`id`, `user_id`, `code`, `completed`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'z3tId1viznsA2kTut4TLLOu86H6nqYr7', 1, '2016-02-23 03:32:28', '2016-02-23 03:32:28', '2016-02-23 03:32:28'),
(2, 2, 'SuYqY0JtQmfqZNjHNlTcP2QAXiPw1HaA', 1, '2016-02-23 03:33:40', '2016-02-23 03:33:40', '2016-02-23 03:33:40'),
(3, 3, 'bkRBpAjW4eHr5oVG5hhmAJpfdMjxnT6S', 1, '2016-02-23 03:40:57', '2016-02-23 03:40:57', '2016-02-23 03:40:57'),
(4, 4, 'oulBWFQ6DFwdbqrPkWkdx1lX3lWewqWv', 1, '2016-02-23 03:42:37', '2016-02-23 03:42:36', '2016-02-23 03:42:37'),
(5, 5, 'r9acvYkkGb5rS1gPns7U4vMadkzfkUaO', 1, '2016-02-23 03:46:03', '2016-02-23 03:46:03', '2016-02-23 03:46:03'),
(6, 6, 'J69VNfW09yu8DYbQnIoAfZjCUuX1n4DV', 1, '2016-02-23 04:00:23', '2016-02-23 04:00:23', '2016-02-23 04:00:23'),
(7, 10, 'nFghHK7a7Cf8XsIetolmjhbgu70uyCaF', 1, '2016-02-23 04:03:08', '2016-02-23 04:03:07', '2016-02-23 04:03:08'),
(8, 11, 'CPTPHSFudYIzwsrFyt4klhxmWHreci7e', 1, '2016-02-23 04:13:44', '2016-02-23 04:13:44', '2016-02-23 04:13:44'),
(9, 12, 'WHWgwNOWVtRJCnRYOfshWRpxGSkDUfhL', 1, '2016-02-23 04:14:07', '2016-02-23 04:14:07', '2016-02-23 04:14:07'),
(10, 13, 'kstFmk4MPTFQ5zi8oiUvbRJfof9ujhAE', 1, '2016-02-23 04:44:18', '2016-02-23 04:44:17', '2016-02-23 04:44:18');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `slug`, `description`, `image`, `created_at`, `updated_at`) VALUES
(19, 'Installing Laravel', 'installing-laravel', 'Via Laravel Installer\r\n\r\nFirst, download the Laravel installer using Composer:\r\n\r\ncomposer global require "laravel/installer"\r\nMake sure to place the ~/.composer/vendor/bin directory (or the equivalent directory for your OS) in your PATH so the laravel executable can be located by your system.\r\n\r\nOnce installed, the laravel new command will create a fresh Laravel installation in the directory you specify. For instance, laravel new blog will create a directory named blog containing a fresh Laravel installation with all of Laravel''s dependencies already installed. This method of installation is much faster than installing via Composer:\r\n\r\nlaravel new blog\r\nVia Composer Create-Project\r\n\r\nAlternatively, you may also install Laravel by issuing the Composer create-project command in your terminal:\r\n\r\ncomposer create-project --prefer-dist laravel/laravel blog', 'Laravel-5.png', '2016-03-02 02:45:12', '2016-03-02 02:45:12'),
(20, 'Middleware introducation', 'middleware-introducation', 'HTTP middleware provide a convenient mechanism for filtering HTTP requests entering your application. For example, Laravel includes a middleware that verifies the user of your application is authenticated. If the user is not authenticated, the middleware will redirect the user to the login screen. However, if the user is authenticated, the middleware will allow the request to proceed further into the application.\r\n\r\nOf course, additional middleware can be written to perform a variety of tasks besides authentication. A CORS middleware might be responsible for adding the proper headers to all responses leaving your application. A logging middleware might log all incoming requests to your application.\r\n\r\nThere are several middleware included in the Laravel framework, including middleware for maintenance, authentication, CSRF protection, and more. All of these middleware are located in the app/Http/Middleware directory.', 'middleware.jpg', '2016-03-02 03:15:51', '2016-03-02 03:15:51'),
(21, 'Sentinel Mamual', 'sentinel-mamual', 'A modern and framework agnostic authorization and authentication package featuring roles, permissions, custom hashing algorithms and additional security features.\r\n\r\nThe package follows the FIG standard PSR-4 to ensure a high level of interoperability between shared PHP code.\r\n\r\nThe package requires PHP 5.4+ and comes bundled with a Laravel 5 Facade and a Service Provider to simplify the optional framework integration.\r\n\r\nHave a read through the Installation Guide and on how to Integrate it with Laravel 5.', 'download.jpg', '2016-03-03 02:56:40', '2016-03-03 02:56:40'),
(22, 'VINAYAK', 'vinayak', 'DJAJDAF', '', '2016-03-03 02:58:02', '2016-03-03 02:58:02'),
(23, 'dfasd', 'dfasd', '', 'MalakeptToSecunderabad', '2016-03-21 00:53:14', '2016-03-21 00:53:14'),
(24, 'fsaf', 'fsaf', 'asfasf', 'MalakeptToSecunderabad', '2016-03-29 01:24:05', '2016-03-29 01:24:05'),
(25, 'asdfsaf', 'asdfsaf', 'sdafsaf', 'a601cb579cc9a289bc51cd41d8bcf478_large.jpg', '2016-04-02 12:04:30', '2016-04-02 12:04:30');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `blog_id` int(11) NOT NULL,
  `comment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `blog_id`, `comment`, `comment_status`, `created_at`, `updated_at`) VALUES
(1, 19, 'hghdfhdh', 0, '2016-03-03 04:45:11', '2016-03-03 04:45:11'),
(2, 19, 'hghdfhdh', 0, '2016-03-03 04:46:33', '2016-03-03 04:46:33'),
(3, 19, '', 0, '2016-03-03 04:46:35', '2016-03-03 04:46:35'),
(4, 19, 'asfaf', 0, '2016-03-03 04:55:27', '2016-03-03 04:55:27'),
(5, 19, 'asfaf', 0, '2016-03-03 04:56:04', '2016-03-03 04:56:04'),
(6, 19, '', 0, '2016-03-03 04:56:23', '2016-03-03 04:56:23'),
(7, 19, 'sff', 0, '2016-03-03 04:56:30', '2016-03-03 04:56:30');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `parent_id`, `created_at`, `updated_at`) VALUES
(1, 'india', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Andhra Pradesh', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Arunachal Pradesh', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Assam', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Hyderabad ', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Amravathi', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_07_02_230147_migration_cartalyst_sentinel', 1),
('2014_10_12_100000_create_password_resets_table', 2),
('2016_03_02_055621_create_table_blogs', 3),
('2016_03_02_055753_create_table_comment', 3),
('2016_03_04_041553_create_location_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `persistences`
--

CREATE TABLE `persistences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `persistences`
--

INSERT INTO `persistences` (`id`, `user_id`, `code`, `created_at`, `updated_at`) VALUES
(1, 13, 'I7L8QGgfcyFkmxvbR1xrURAvoMuNmeMx', '2016-02-23 04:45:25', '2016-02-23 04:45:25'),
(2, 13, 'Y3kORZPhtoHQf3kWkmvJZZIlUJIABYR2', '2016-02-23 04:57:28', '2016-02-23 04:57:28'),
(3, 13, 'zdgaXi7pQH9C4sG0Iue7LxhfuokXeFIM', '2016-02-23 04:57:28', '2016-02-23 04:57:28'),
(4, 13, '6pbU68Pfcp0vH3rihdGkQmCu3gVcTc6X', '2016-02-23 04:58:25', '2016-02-23 04:58:25'),
(5, 13, 'Se0eYsA1crrFxxhqoRyfJPSOwWK1e66k', '2016-02-23 04:58:25', '2016-02-23 04:58:25'),
(6, 13, 'Wz3dGQVI3ls7cHTHgmt3m8zMSasRpN5s', '2016-02-23 05:12:27', '2016-02-23 05:12:27'),
(7, 13, 'tqJ1yH8MJwxcDNEAQo8NdejG4Q5jIlLv', '2016-02-23 05:12:27', '2016-02-23 05:12:27'),
(8, 13, '55nIwssQ6eNibTJMsjIGUp7C9VVlxTz4', '2016-02-23 05:14:23', '2016-02-23 05:14:23'),
(9, 13, '3HvXRbh21RElMuaDnoslek7KYPdhnHIo', '2016-02-23 05:14:23', '2016-02-23 05:14:23'),
(10, 13, 'DjEoNcpP023ZQjp38AZnenlwDGtWADkw', '2016-02-23 05:23:09', '2016-02-23 05:23:09'),
(11, 13, '3FRnCZtqrM5TkvoDD3YqU79OSvDXkB3Z', '2016-02-23 05:23:09', '2016-02-23 05:23:09'),
(12, 13, 'jH2rHxzqo7iIfNDMBQ6CUnXOTo6qdTA3', '2016-02-23 05:25:02', '2016-02-23 05:25:02'),
(13, 13, 'nxxzDwe2KWNtZDzKDRqOSBcckEYb1mzl', '2016-02-23 05:25:02', '2016-02-23 05:25:02'),
(14, 13, 'IaWvdzyIrtrQHHU7H9xJjjpyyWTDsj1E', '2016-02-23 05:25:47', '2016-02-23 05:25:47'),
(16, 13, 'GinalRzjZLQV7jyF7SKvievkZO38Sgb2', '2016-02-23 05:28:34', '2016-02-23 05:28:34'),
(17, 13, 'tgJvQ4lWLUmR0GsZRsvrnZQ6VtqOQn5y', '2016-02-23 05:28:34', '2016-02-23 05:28:34'),
(18, 13, 'NDcymd10GLTF44dItu98ARPtoKOnmfFI', '2016-02-23 05:28:51', '2016-02-23 05:28:51'),
(19, 13, 'ycHJL7Tall6VGEDAzrDRAyOZQgoi1gOH', '2016-02-23 23:53:06', '2016-02-23 23:53:06'),
(20, 13, 'B6ib9iTOesW8MhspD1PuSOz5KBmi7ez0', '2016-03-01 02:43:12', '2016-03-01 02:43:12'),
(22, 13, 'F3U3mRi09HNOigctVDJg75dcBPuvdKIQ', '2016-03-01 02:43:21', '2016-03-01 02:43:21'),
(24, 13, 'VVzxegRf4M4l2u7PynPLLXfutdCSkGW8', '2016-03-01 02:43:28', '2016-03-01 02:43:28'),
(26, 13, 'kffUKW1ZOnHk6MeaypCllTgmIVc4nIMR', '2016-03-01 02:43:34', '2016-03-01 02:43:34'),
(28, 13, 'gFWSPFDwfENh0MwY9CpOpOiony5PyBPb', '2016-03-01 02:43:39', '2016-03-01 02:43:39'),
(30, 13, 'ez2tOobnfAbwDYaIFWEBOpKKswIJcat5', '2016-03-01 02:43:44', '2016-03-01 02:43:44'),
(32, 13, 'xztcUCvCI4qS0aNoOksjIzPkOrXUiyGW', '2016-03-01 02:45:57', '2016-03-01 02:45:57'),
(33, 13, 'Lq66xdhz909iB844oASH9j4PolOY75pD', '2016-03-01 02:45:57', '2016-03-01 02:45:57'),
(34, 13, '2WzOzfTUAHeHJurZrERrZf95omBTGYVS', '2016-03-03 00:00:06', '2016-03-03 00:00:06'),
(36, 13, 'kfJqfeMXvg6KcA15y6c5RWSA3kFMfVlF', '2016-03-03 00:07:48', '2016-03-03 00:07:48'),
(38, 13, 'WFjWgrMReSUtulZPOT6TI0uRgRHFl5fy', '2016-03-03 01:39:35', '2016-03-03 01:39:35'),
(40, 13, 'LPYfuk3CXIe6c4zWO3LW1Y47SytNfW6V', '2016-03-03 01:44:55', '2016-03-03 01:44:55'),
(42, 13, 'ErHKInjY9nmNHIrjt215nh3ozEakF9tL', '2016-03-03 02:55:18', '2016-03-03 02:55:18'),
(44, 13, 'SrsDwwqeHcakSv43fBllEtHZWSETUgYT', '2016-03-03 03:35:51', '2016-03-03 03:35:51'),
(46, 13, 'eWYlPxsKwVvb8KKp9sinb0IGVDMWQM1O', '2016-03-03 03:59:29', '2016-03-03 03:59:29'),
(48, 13, 'iuzYlqu6NaH2bLqNX6yO68khhGnb5fyM', '2016-03-03 04:00:36', '2016-03-03 04:00:36'),
(50, 13, 'YqJFLZ73jOyx7e5y7qg8r1I4oW5R3mco', '2016-03-03 04:05:33', '2016-03-03 04:05:33'),
(52, 13, 'GEDMYLDcb7vKxbPmMzaGopz2rU6RzXIX', '2016-03-03 04:06:20', '2016-03-03 04:06:20'),
(54, 13, 'hUiLOEu5rFAeJ4ayg3ooj7P7YgfzO1d0', '2016-03-03 04:07:41', '2016-03-03 04:07:41'),
(56, 13, '6TwhVouB53mN451HdNHH6FMnYSWKTGEm', '2016-03-03 04:08:48', '2016-03-03 04:08:48'),
(57, 13, 'ftydXsz4LcaoZLY2T8c3qu0GjdRQVg4m', '2016-03-03 04:08:48', '2016-03-03 04:08:48'),
(58, 13, 'fx5l1USmZbDtBSC28eKnz8OquzdYCMOT', '2016-03-03 04:10:12', '2016-03-03 04:10:12'),
(59, 13, 'Y1NyhrRkTIcY2CvLeCBfT6rDhlMIixJX', '2016-03-03 04:10:12', '2016-03-03 04:10:12'),
(60, 13, 'BuKahdFoDwxhrFIGCW0ASo2R7UySneDG', '2016-03-03 04:10:28', '2016-03-03 04:10:28'),
(61, 13, 'QEBaZz7EnyNJMDVAeinR7kxeLsd8Zz8C', '2016-03-03 04:10:28', '2016-03-03 04:10:28'),
(62, 13, 'rFVwYoNzXCvRKry53gIps4qRvJSQtVrG', '2016-03-03 04:11:24', '2016-03-03 04:11:24'),
(63, 13, 't8ACThZhO34bhJzEM6FGBvklNMw3FyWE', '2016-03-03 04:11:24', '2016-03-03 04:11:24'),
(64, 13, 'ES5r8pZ9AIAKdsbkCSlL0OftYAggPWNE', '2016-03-03 04:12:12', '2016-03-03 04:12:12'),
(65, 13, 'JkfLq91tcWAjORDkcTnOtAJFCyznBsYU', '2016-03-03 04:12:12', '2016-03-03 04:12:12'),
(66, 13, 'xWij3WzL3pZM4LquW5iYvGHriNhuHK7r', '2016-03-03 04:12:21', '2016-03-03 04:12:21'),
(67, 13, '6O8nXDy03pEccWGWVKa5v0sk21fxETKY', '2016-03-03 04:12:21', '2016-03-03 04:12:21'),
(68, 13, 'ojWxLz0yomSDXOqjeYwEAj3fAipQQ9yk', '2016-03-03 04:12:32', '2016-03-03 04:12:32'),
(69, 13, 'I042ewTuAXlfJ4gegANaTcaR7HKWVZfR', '2016-03-03 04:12:32', '2016-03-03 04:12:32'),
(70, 13, 'FIYTnCA46Pz9XGGxZEPfMqzTT5iUiuLq', '2016-03-03 04:12:58', '2016-03-03 04:12:58'),
(71, 13, 'In2S5aTTgE1PclMqnh3f8kbEmzpq8ToN', '2016-03-03 04:12:58', '2016-03-03 04:12:58'),
(72, 13, 'v8K0M7pbUUxhJYXmsAIohWTOXrwtybbo', '2016-03-03 04:13:22', '2016-03-03 04:13:22'),
(73, 13, 'etU1IuktW92LoZBq6Yr5Wy9g7rYTODf0', '2016-03-03 04:13:22', '2016-03-03 04:13:22'),
(74, 13, 'OuIxfF2wYdrtuAsqCius0eQCGOrhZiXJ', '2016-03-03 04:13:58', '2016-03-03 04:13:58'),
(75, 13, 'J48fSbebqDaSHu5wUMCXnXPGT7vHPx9s', '2016-03-03 04:13:58', '2016-03-03 04:13:58'),
(76, 13, 'c7tDeq1UG2eruRVsMguCKwPAIx6RGS77', '2016-03-03 04:15:41', '2016-03-03 04:15:41'),
(77, 13, 'ZOnKXKDEwjtSAClfNL7zJFS58HPRBgJb', '2016-03-03 04:15:41', '2016-03-03 04:15:41'),
(78, 13, '4eWMfvfSjOj9vo2XKqV0dAqs33ZuGUme', '2016-03-03 04:15:52', '2016-03-03 04:15:52'),
(79, 13, 'HQIMyO4zpX8p56KJR5KxNESbZ40CT75t', '2016-03-03 04:15:52', '2016-03-03 04:15:52'),
(80, 13, 'vcYxfOrHugvBd8LZvCzrWpAkM8hcDjjQ', '2016-03-03 04:16:36', '2016-03-03 04:16:36'),
(81, 13, 'UNAPk4aDs1Vn6LVwdmBM1D14ItvY1Opf', '2016-03-03 04:16:36', '2016-03-03 04:16:36'),
(82, 13, 'J0hH6sPeTgf3H95YDSf2n5w4m7e6H3Hr', '2016-03-03 04:16:54', '2016-03-03 04:16:54'),
(83, 13, 'bkTc5MAHcRdl5YwLe4B06neOj42aZNoT', '2016-03-03 04:16:54', '2016-03-03 04:16:54'),
(84, 13, 'PTU3Zw1hr1QXmtns8Ak7xQdwfXXoCAo9', '2016-03-03 04:16:57', '2016-03-03 04:16:57'),
(85, 13, '8TuV7Tw9k6aM8HThOTkZ5LqgLHdpIM7W', '2016-03-03 04:16:58', '2016-03-03 04:16:58'),
(86, 13, '0958IW72OJSoOgUPdeuyIaVxIRxMVPlG', '2016-03-03 04:17:13', '2016-03-03 04:17:13'),
(87, 13, 'wUAEBWn2qUZmYy3QPXqd1CMOpkl5bOfR', '2016-03-03 04:17:13', '2016-03-03 04:17:13'),
(88, 13, 'hjm4D3cE7jCTUnaipyDxnwsOS1nOEHiN', '2016-03-03 04:17:27', '2016-03-03 04:17:27'),
(89, 13, 'hIinQOnhWCQWf8vAGeMDKk13mOEX654h', '2016-03-03 04:17:27', '2016-03-03 04:17:27'),
(90, 13, '1dGNU1dSvpxJOtm96rIitVm0eic2eEpe', '2016-03-03 04:17:34', '2016-03-03 04:17:34'),
(91, 13, '3JOjktpRJKqQYk41bOT8brmB6Ko3rFsd', '2016-03-03 04:17:34', '2016-03-03 04:17:34'),
(92, 13, 'ud9h4WnIFRu3MVISpcwSEKcRUhEXXFOh', '2016-03-03 04:17:40', '2016-03-03 04:17:40'),
(93, 13, 'KmYoDDL5g3CE5ec8izugX32sofKAsDd9', '2016-03-03 04:17:40', '2016-03-03 04:17:40'),
(94, 13, 'zvvg2AKC6Z7l4IMfTvYtzsuoTehwGEFV', '2016-03-03 04:18:00', '2016-03-03 04:18:00'),
(95, 13, 'rxGAHWSWHcTBRZW4zuFoHEb02SLdClDw', '2016-03-03 04:18:00', '2016-03-03 04:18:00'),
(96, 13, 'K2GzCM1t7LLK3TaG5ximm5bm8MLzzzh0', '2016-03-03 04:18:07', '2016-03-03 04:18:07'),
(97, 13, 'Yw9WptcNxbiByf0OdmO6tHuE8gejMcCV', '2016-03-03 04:18:07', '2016-03-03 04:18:07'),
(98, 13, 'cAYOimhiJsdH3w7xB4B5ChKKjWaD62CS', '2016-03-03 04:18:19', '2016-03-03 04:18:19'),
(99, 13, 'XxnxQfIMzBx7OeK4IkqMSGvpGBdZhcoY', '2016-03-03 04:18:19', '2016-03-03 04:18:19'),
(100, 13, 'jVrepTp0qm1nobu70I2X9MaZQU8mC02G', '2016-03-03 04:19:13', '2016-03-03 04:19:13'),
(102, 13, 'ZexH2GX67f6pAqHPng0VLuB6chOqUVHn', '2016-03-03 04:19:25', '2016-03-03 04:19:25'),
(103, 13, 'qgqD0vm0SdKoS35OElXPhB8ax7rUnNXv', '2016-03-03 04:19:25', '2016-03-03 04:19:25'),
(104, 13, 'v6TOO4nkjYSEZAaj2ClX5gWzBnwpi9mt', '2016-03-03 04:19:31', '2016-03-03 04:19:31'),
(106, 13, 'i2ysQSWRrwuY6dGZsdPO3t7a3DrMvqwx', '2016-03-03 04:19:51', '2016-03-03 04:19:51'),
(107, 13, 'QXTFA3bYEP3Mkj3vS6XYfIeSBvmX5w55', '2016-03-03 04:19:51', '2016-03-03 04:19:51'),
(108, 13, '0YELevlwoJHWaiJSrHQI7tMj9fIwC189', '2016-03-03 04:20:01', '2016-03-03 04:20:01'),
(109, 13, 'NVPcXMfK9yxhJOm3zxCI5CaqPUbMexAC', '2016-03-03 04:20:01', '2016-03-03 04:20:01'),
(110, 13, 'uQGSsMTYyXFiC9rChbfLEvMEQY2e7BFd', '2016-03-03 04:20:22', '2016-03-03 04:20:22'),
(111, 13, 'DqNvWOenUKextM13AehcyHKoOGvSI2K0', '2016-03-03 04:20:23', '2016-03-03 04:20:23'),
(112, 13, 'GF49ek16hBg4QjsAazP7i1O6tguzjDdB', '2016-03-03 04:20:30', '2016-03-03 04:20:30'),
(113, 13, 'k3nUxGiF8ibxUjGejdZPpx2Vt1pHcZRn', '2016-03-03 04:20:30', '2016-03-03 04:20:30'),
(114, 13, 'otipF3hOMP72HZlVdsfyxCCFkCSuciXS', '2016-03-03 04:20:35', '2016-03-03 04:20:35'),
(115, 13, 'xq0lpM82m3cMGE1ndEdyhwD87is8D7Tf', '2016-03-03 04:20:35', '2016-03-03 04:20:35'),
(116, 13, 'oIdIhYvJaqXl7IBwEpYNTDp29XaOf8Pm', '2016-03-03 04:20:50', '2016-03-03 04:20:50'),
(118, 13, '3Pzkj1fPPpiZ9fc8tfaOt29Sqof9Xdca', '2016-03-03 04:22:06', '2016-03-03 04:22:06'),
(119, 13, 'uTb7kWLKZ8clnT4vF5iW8OvBild5Vi42', '2016-03-03 04:22:06', '2016-03-03 04:22:06'),
(120, 13, 'JLcWQZ2SDnIt9RVCtiM28HprI60w62Tt', '2016-03-03 04:22:24', '2016-03-03 04:22:24'),
(121, 13, 'YueGLnYJlHn8SxsUIEHY96rjiXFqMMlF', '2016-03-03 04:22:25', '2016-03-03 04:22:25'),
(122, 13, 'YAB3ybY1L4DBhMo7goYtd4rE8Ra7RI8F', '2016-03-03 04:22:37', '2016-03-03 04:22:37'),
(123, 13, 'qsL3f86FVR8hovwhDA0t1KUDv28xDYRc', '2016-03-03 04:22:37', '2016-03-03 04:22:37'),
(124, 13, 'LQV4DZzPMWN1BN5QfSgXgK4tO1FMTS1U', '2016-03-03 04:23:10', '2016-03-03 04:23:10'),
(125, 13, 'wtlQkAzHqjuprHnxyOgjmAO1hfGqIXHk', '2016-03-03 04:23:10', '2016-03-03 04:23:10'),
(126, 13, 'yEIETV3mvUnk6jS1dI7MXnDdlSBW7uzT', '2016-03-03 04:23:39', '2016-03-03 04:23:39'),
(127, 13, 'gmgph3XzkELO1erlXYvd9DEoiwq8jpbe', '2016-03-03 04:23:40', '2016-03-03 04:23:40'),
(128, 13, 'QGjkAn4hysIw4GW22Z6EGpDyT9bj9oDp', '2016-03-03 04:23:52', '2016-03-03 04:23:52'),
(130, 13, '7AkWuDYuXPo4ZuQuo5QlXxWs6KZ0F6xT', '2016-03-03 04:25:21', '2016-03-03 04:25:21'),
(132, 13, '4h7RQZ1OmGSU0Nf5ZuiC1qHiOK7kzhKu', '2016-03-03 04:27:50', '2016-03-03 04:27:50'),
(134, 13, '3r1I80Q0vj8JyYK0HdLEPcBMO3jIrTX5', '2016-03-03 04:45:11', '2016-03-03 04:45:11'),
(136, 13, 'J1sQaM0KSxCxnBGx07isESbyscwMfgSs', '2016-03-03 04:55:26', '2016-03-03 04:55:26'),
(138, 13, 'u7qBQfVujE7eEkLsNHRZI0S1c35PHRzL', '2016-03-03 04:56:03', '2016-03-03 04:56:03'),
(139, 13, 'wE8xpluveLkmrYXis8KbNFBjtSbocWp4', '2016-03-03 04:56:03', '2016-03-03 04:56:03'),
(140, 13, 'inQWM7o35S86grp5dbmcvIbVaqPea0iE', '2016-03-29 00:44:25', '2016-03-29 00:44:25'),
(142, 13, 'D1bfHbz26ZbxwaUHdmnxx2RmQhQKyqJj', '2016-03-29 00:45:17', '2016-03-29 00:45:17'),
(144, 13, 'ltZRGWmZmTXFcWCMj2MoFLnT8F6U3RAs', '2016-03-29 00:54:31', '2016-03-29 00:54:31'),
(146, 13, 'rLlLRCINVRqUMXKUm4MfJ8bA1pGXYkNA', '2016-03-29 01:02:22', '2016-03-29 01:02:22'),
(148, 13, 'H5JTzGCzWlaOqyRLU2vYz5pUIPJh7wtS', '2016-03-29 01:31:39', '2016-03-29 01:31:39'),
(150, 13, '8oVw3jomE22TXHCBkNJff9PZPnX7v4yp', '2016-03-29 01:33:38', '2016-03-29 01:33:38'),
(152, 13, 'BoOzwnAem3m2jO4MYk43uyAgjIh3VAOq', '2016-03-29 01:35:32', '2016-03-29 01:35:32'),
(154, 13, 'xsOP1s4tWAMHsdpZ4QFLJyTI0ZDaUrAM', '2016-03-29 01:45:57', '2016-03-29 01:45:57'),
(156, 13, 'HM0hnhVDRCfFcRJRFs3ftpNY8RJAIh7i', '2016-03-29 01:52:35', '2016-03-29 01:52:35'),
(158, 13, 'KTMiII0mtMiMXxPu1p5NYWh72AH9VBwA', '2016-03-29 02:02:33', '2016-03-29 02:02:33'),
(159, 13, 'P4XSpcdpkGXRFqPOYHh8ObvIAKLX7WQH', '2016-03-29 02:02:33', '2016-03-29 02:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `user_id` int(250) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `user_id`, `rating`, `created_at`, `updated_at`) VALUES
(1, 13, 3, '2016-03-29 01:30:21', '2016-03-29 01:30:21'),
(2, 13, 3, '2016-03-29 01:37:17', '2016-03-29 01:37:17'),
(3, 13, 4, '2016-03-29 01:38:07', '2016-03-29 01:38:07'),
(4, 13, 4, '2016-03-29 01:38:39', '2016-03-29 01:38:39'),
(5, 13, 1, '2016-03-29 01:40:39', '2016-03-29 01:40:39'),
(6, 13, 3, '2016-03-29 01:41:03', '2016-03-29 01:41:03'),
(7, 13, 4, '2016-03-29 01:42:03', '2016-03-29 01:42:03'),
(8, 13, 3, '2016-03-29 01:45:20', '2016-03-29 01:45:20'),
(9, 13, 4, '2016-03-29 01:45:33', '2016-03-29 01:45:33');

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

CREATE TABLE `reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `slug`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', NULL, '2016-02-23 02:49:59', '2016-02-23 02:49:59'),
(3, 'editor', 'Editor', NULL, '2016-02-23 02:50:44', '2016-02-23 02:50:44'),
(4, 'seo', 'SEO', NULL, '2016-02-23 02:50:55', '2016-02-23 02:50:55'),
(5, 'sales-marketing', 'Sales & Marketing', NULL, '2016-02-23 02:51:12', '2016-02-23 02:51:12'),
(6, 'developer', 'developer', NULL, '2016-02-23 03:03:36', '2016-02-23 03:03:36'),
(7, 'author', 'author', NULL, '2016-02-23 23:56:57', '2016-02-23 23:56:57'),
(8, 'vinakyak', 'vinakyak', NULL, '2016-04-02 12:05:50', '2016-04-02 12:05:50'),
(9, '', '', NULL, '2016-04-02 12:11:17', '2016-04-02 12:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `role_users`
--

CREATE TABLE `role_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role_users`
--

INSERT INTO `role_users` (`user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(10, 4, '2016-02-23 04:03:08', '2016-02-23 04:03:08'),
(11, 6, '2016-02-23 04:13:44', '2016-02-23 04:13:44'),
(12, 3, '2016-02-23 04:14:07', '2016-02-23 04:14:07'),
(13, 3, '2016-02-23 04:44:18', '2016-02-23 04:44:18');

-- --------------------------------------------------------

--
-- Table structure for table `throttle`
--

CREATE TABLE `throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `throttle`
--

INSERT INTO `throttle` (`id`, `user_id`, `type`, `ip`, `created_at`, `updated_at`) VALUES
(1, NULL, 'global', NULL, '2016-02-23 04:42:50', '2016-02-23 04:42:50'),
(2, NULL, 'ip', '127.0.0.1', '2016-02-23 04:42:50', '2016-02-23 04:42:50'),
(3, NULL, 'global', NULL, '2016-02-23 04:43:07', '2016-02-23 04:43:07'),
(4, NULL, 'ip', '127.0.0.1', '2016-02-23 04:43:07', '2016-02-23 04:43:07'),
(5, NULL, 'global', NULL, '2016-02-23 04:57:11', '2016-02-23 04:57:11'),
(6, NULL, 'ip', '127.0.0.1', '2016-02-23 04:57:11', '2016-02-23 04:57:11'),
(7, NULL, 'global', NULL, '2016-02-23 05:14:05', '2016-02-23 05:14:05'),
(8, NULL, 'ip', '127.0.0.1', '2016-02-23 05:14:05', '2016-02-23 05:14:05'),
(9, NULL, 'global', NULL, '2016-04-02 12:24:16', '2016-04-02 12:24:16'),
(10, NULL, 'ip', '::1', '2016-04-02 12:24:16', '2016-04-02 12:24:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `permissions`, `last_login`, `first_name`, `last_name`, `created_at`, `updated_at`) VALUES
(3, 'vinayak@gmail.com', '$2y$10$wcSnRXeS/qMV1JY5UXLADuNMJySB7UaQY1z3.vpgFm2PfAfIiPgEG', NULL, NULL, NULL, NULL, '2016-02-23 03:40:57', '2016-02-23 03:40:57'),
(4, 'naresh@gmail.com', '$2y$10$6/ow3YQJEht0ZjVTnWyV8.ygzUF6He0II/7Tq7rgdPTJCxN5RtXNq', NULL, NULL, NULL, NULL, '2016-02-23 03:42:36', '2016-02-23 03:42:36'),
(5, 'naresh1@gmail.com', '$2y$10$Q9PbIiS2PClFGZP5.g1ns.8gpXJA5pCgfg4evUDv0dmotVoCYE2cq', NULL, NULL, 'naresh', 'kumq', '2016-02-23 03:46:03', '2016-02-23 03:46:03'),
(6, 'sri@gmail.com', '$2y$10$GP8fxsZJxZHXusj0hZmVUeN0tOTME7A0R9thk58odL9eDb6Ex4oIO', NULL, NULL, 'sri', 'kanth', '2016-02-23 04:00:23', '2016-02-23 04:00:23'),
(10, 'sssss@dfgdgdg.jk', '$2y$10$oNGfTUta87/lnmEkI33S0.ArIuI1ehDfXI6C/nV1XNVXn1Rljd/i2', NULL, NULL, 'sdfsfsdf', 'dsfdsfgsfd', '2016-02-23 04:03:07', '2016-02-23 04:03:07'),
(11, 'murli2@gmail.com', '$2y$10$6wesYWPcri4C0LInZfBvnuKfuZPPZ8t.u/81KOYEUJ0OZJlhbcIeq', NULL, NULL, 'murli', 'kumar', '2016-02-23 04:13:44', '2016-02-23 04:13:44'),
(12, 'de@gmail.com', '$2y$10$LBxX3VC2HOeRHKx6CBm.K.VxOnrcWtCc5RVeDM/xIunWK6wMVzb9C', NULL, NULL, ' vinayak', 'dhayap', '2016-02-23 04:14:07', '2016-02-23 04:14:07'),
(13, 'som@som.com', '$2y$10$TfDODPGcDsZcUzYKIaJf9O9FQxFbcuQB2/yC.uBl8hFOBYUqXqasC', NULL, '2016-03-29 02:02:33', 'som', 'som', '2016-02-23 04:44:17', '2016-03-29 02:02:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activations`
--
ALTER TABLE `activations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `persistences`
--
ALTER TABLE `persistences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `persistences_code_unique` (`code`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reminders`
--
ALTER TABLE `reminders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_users`
--
ALTER TABLE `role_users`
  ADD PRIMARY KEY (`user_id`,`role_id`);

--
-- Indexes for table `throttle`
--
ALTER TABLE `throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `throttle_user_id_index` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activations`
--
ALTER TABLE `activations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `persistences`
--
ALTER TABLE `persistences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;
--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `reminders`
--
ALTER TABLE `reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `throttle`
--
ALTER TABLE `throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
