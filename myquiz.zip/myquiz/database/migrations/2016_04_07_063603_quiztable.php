<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class Quiztable extends Migration {
	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up() {
		Schema::create('questions', function (Blueprint $table) {
			$table->increments('id');
			$table->string('question', 500);
			$table->timestamps();
		});

		Schema::create('answers', function (Blueprint $table) {
			$table->increments('id');
			$table->string('answer', 500);
			$table->integer('question_id');
			$table->timestamps();
		});

		Schema::create('results', function (Blueprint $table) {
			$table->increments('id');
			$table->integer('question_id');
			$table->integer('answer_id');
			$table->timestamps();
		});

		Schema::create('user_result', function (Blueprint $table) {
			$table->increments('id');
			$table->integer('user_id');
			$table->integer('question_id');
			$table->integer('answer_id');
			$table->timestamps();
		});

	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down() {
		//
	}
}
