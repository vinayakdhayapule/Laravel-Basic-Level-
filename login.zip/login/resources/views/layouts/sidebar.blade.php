<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li class="sidebar-brand">
            <a href="#">
                Infyom Generator
            </a>
        </li>
       @include('layouts.menu')
    </ul>
</div>