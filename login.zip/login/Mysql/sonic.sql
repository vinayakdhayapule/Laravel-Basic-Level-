-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 17, 2016 at 05:19 PM
-- Server version: 5.5.44-0ubuntu0.14.04.1
-- PHP Version: 5.6.19-1+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sonic`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=40 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(9, 'vinnu', 'vinnu@live.com', '$2y$10$FB.LoEakODCFdKKI1b2tX.SFEVjUeRNhrvJ/vPZrStZHzVK2faAG.', NULL, '2016-05-14 05:21:39', '2016-05-14 05:21:39'),
(10, 'erwr', 'admin@ee.com', '$2y$10$mYHkbABaAUshccl2M49NOeeRTuVm61Mx8GmE0UZDSb/6/BFoEzS3S', NULL, '2016-05-14 06:24:19', '2016-05-14 06:24:19'),
(11, 'qewqe', 'admin@admin.comwew', '$2y$10$DDioLuu1yIjPlTMu8eiJzeAoDuG0jr8ye5cBb/nHFDRXVW9L/SoUi', NULL, '2016-05-14 06:24:50', '2016-05-14 06:24:50'),
(12, '', 'admin@admin.com', '$2y$10$Azu1zL5v0ShwDXdiS9YNC.a9fjYFtz0hyil1dPzN0P8m3MJ0soB8W', NULL, '2016-05-14 06:33:07', '2016-05-14 06:33:07'),
(14, 'fdsgsd', 'dfg@admin.com', '$2y$10$kznbaFRQn3Ia.32F1/7y1e7F6BjZh4zSuRmHnUpv5FK/TPVhw97DS', NULL, '2016-05-14 06:33:48', '2016-05-14 06:33:48'),
(15, 'vinayak', 'vinay@gmail.com', '$2y$10$GguTRoBXU2Mee/SSOAZRtOOh9V6nprFDaVX2bhU2PCJw6XLIrQ8JK', NULL, '2016-05-15 23:41:12', '2016-05-15 23:41:12'),
(16, 'sri', 'sri@gmail.com', '$2y$10$zDgXHzUS6WofyZg.wuHsA.d2ffdZNJ3k3trfQ8wv3uEdfBlE9DvyS', NULL, '2016-05-15 23:43:50', '2016-05-15 23:43:50'),
(17, 'murli', 'demod@gmail.com', '$2y$10$MW1srT3gnvv1m3vtj3.wBuHghzNb15VD4bB8c6y24qbNjubmZjdfq', NULL, '2016-05-15 23:45:10', '2016-05-15 23:45:10'),
(18, 'naresh', 'naresh@gmail.com', '$2y$10$ORK7FMnFrEoMY5LICyh/m.lsTy3lPmqeL8WX3.YM6EZDlATF3jrJy', NULL, '2016-05-15 23:48:29', '2016-05-15 23:48:29'),
(19, 'vinayakdhayapule', 'vinayakdhayapule@gmail.com', '$2y$10$CLHnzZg.jMHnJzfAm6bSQOl6pGS2jNgXWvQNXvpn3kjlBHvPDw/NK', NULL, '2016-05-16 00:51:03', '2016-05-16 00:51:03'),
(20, 'sri', 'sri@sri.com', '$2y$10$qJ5mNYAWwXMDuSDAso/rAOEjFR5aKxzMHDuSCXlPodMtJVUooQmCe', NULL, '2016-05-16 02:44:56', '2016-05-16 02:44:56'),
(21, 'demo', 'demo@demo.com', '$2y$10$d5q4JQyBI6SVaYZyoGWbzuPBcelKET1y2vkUvNDu4g4BZQlIuAQcS', NULL, '2016-05-16 03:02:46', '2016-05-16 03:02:46'),
(22, 'raja', 'raja@gmail.com', '$2y$10$V30GgMcoh74tdox6Aqq5IOnNRxnkmwFKUatitasBg6/k3zPnOuA1y', NULL, '2016-05-16 04:53:39', '2016-05-16 04:53:39'),
(25, 'asdfasdfasd', 'admina@admin.com', '$2y$10$.ptkyD9NM6jGVxw8p6YG8uIACXo/epi1BMxv9favmy2XdANHGjBjK', NULL, '2016-05-17 00:50:49', '2016-05-17 00:50:49'),
(26, 'asdfasdfasd', 'admaina@admin.com', '$2y$10$WCdE8s2SDEE.ripiRN/Rj.Em6D8O/UdsOJA2WweBEGjHMU1ozBsRW', NULL, '2016-05-17 00:51:27', '2016-05-17 00:51:27'),
(27, 'aaaaa', 'admin@admin.coma', '$2y$10$jJ5Wpa1h/LIGVIXlLk/PG.HUicHgdjN6B1ylQVfaYipkeneQ4Lt/q', NULL, '2016-05-17 00:52:10', '2016-05-17 00:52:10'),
(29, 'aaaaa', 'aadmin@admin.coma', '$2y$10$P2viCvLAqtcDDOu4ICo/bO/S7N47TOxyGbJ5cyaTnS9MdwEHYuPSe', NULL, '2016-05-17 00:52:24', '2016-05-17 00:52:24'),
(30, 'weweewe', 'admin@admin.comdfdf', '$2y$10$GERGUiRyn6Wq.sF0zrDikeGE2mB3jXvjFpqPo1LrwfX84bOcjJ0VW', NULL, '2016-05-17 00:54:22', '2016-05-17 00:54:22'),
(31, 'weweewe', 'xczcadmin@admin.comdfdf', '$2y$10$aMFLilCed1KnTz6MMyu98O5VanUfaIcYnocvOH0c31hwwMZixfSy2', NULL, '2016-05-17 00:54:33', '2016-05-17 00:54:33'),
(32, 'fdfd', 'addmin@admin.com', '$2y$10$bs8e5N/QayGiKiWWlfu.gOky396Kr4plxs5JKc4fwInofa1Me5IcG', NULL, '2016-05-17 00:55:40', '2016-05-17 00:55:40'),
(33, 'aa', 'sss@admin.com', '$2y$10$5ffuJpHWnpTmCwHTOjV4/uy2qq/iyTeXFrpgx0iDTW9xljUwbrvUi', NULL, '2016-05-17 00:56:18', '2016-05-17 00:56:18'),
(34, 'eee', 'ee@admin.com', '$2y$10$BJW5bnY8mO6IGhV9ndMZxu/PHbGpM4WZgdIzT89d2ATanxUPInib6', NULL, '2016-05-17 00:56:41', '2016-05-17 00:56:41'),
(35, 'sdsds', 'ss@admin.com', '$2y$10$NUoc.7pYU1nAenUkdw2Cre3HIyzWb8UCkIPlbrWyMwKbJ/ybMHSsi', NULL, '2016-05-17 00:57:09', '2016-05-17 00:57:09'),
(36, 'ssss', 'admin@admin.comfdddd', '$2y$10$vpOF/szXTyrxShjwKKYW/ePIeGdfj2dWGjGz0zwNChu.9lz1xj3xO', NULL, '2016-05-17 00:57:28', '2016-05-17 00:57:28'),
(37, 'dsdsdsdsdsd', 'asdsdsddmin@admin.com', '$2y$10$uH5ZZt6KEGsyG0pBj20eR.yXUSTGaKMzTJNG15Qo8ZprKCthDtNIO', NULL, '2016-05-17 00:58:55', '2016-05-17 00:58:55'),
(38, 'ddddd', 'addddmin@admin.com', '$2y$10$JbrABQqrvlsBbj0srVAkZeypJg6nrKXBJO9.BdiSdZPd1IX/dbWqm', NULL, '2016-05-17 01:05:09', '2016-05-17 01:05:09'),
(39, 'vinnu', 'vinn@gmail.com', '$2y$10$TLiAPrQoSH5yEVJBhjkDoOuQsYuMRtQo1USi956ilXwy9/o1EP.yu', NULL, '2016-05-17 01:37:38', '2016-05-17 01:37:38');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
